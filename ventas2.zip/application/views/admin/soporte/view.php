
	

	<div class="row">
		<div class="col-xs-12" align="center">
		<img src="<?php echo base_url();?>assets/img/logo3.jpg">
		</div>


	</div>

	<div class="row">
		<div class="col-xs-12" align="center">
		<img src="<?php echo base_url();?>assets/img/franja1.jpg">
		</div>
	</div>
	<div class="row">
		<div class="col-xs-12" align="center">
		<h1>INFORME TECNICO</h1>
		</div>


	</div>
	<br>
	<div class="row">
	<div class="col-xs-6">	
		<b>Nombre:</b> <?php echo $informes->nombre; ?> <br>
		
	</div>	
	<div class="col-xs-6">	
	<b>Fecha</b> <?php echo $informes->fecha; ?><br>
	</div>	
	
</div>
<br>
<br>
<div class="row">
	<div class="col-xs-6">	
		<b>Marca / Modelo:</b> <?php echo $informes->marca_modelo; ?> <br>
		<b>Serie:</b> <?php echo $informes->serie; ?> <br>
		<b>Codigo Interno:</b> <?php echo $informes->codigo; ?> <br>
		
	</div>	
	<div class="col-xs-6">
	<b>Valido de Oferta:</b> <?php echo $informes->valido_oferta; ?><br>
    <b>Tiempo de Entrega:</b> <?php echo $informes->tiempo_entrega; ?><br>
    <b>Forma de Pago:</b> <?php echo $informes->forma_pago; ?><br>
	</div>
</div>
<br>

<div class="row">
	<div class="col-xs-12">
	<b>FALLA REPORTADA:</b> <?php echo $informes->falla; ?><br>
	</div>
	<div class="col-xs-12">
	<b>DIAGNOSTICO:</b> <?php echo $informes->diagnostico; ?><br>
	</div>
</div>
<br>

<div class="row">
	<div class="col-xs-12" >
	
		<table class="table table-striped">
		
			<thead>
				<tr>
					<th>Cantidad</th>
					<th>Nombre</th>
					<th>Precio</th>
					
					<th>Importe</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($detalles as $detalle ):?>
				<tr>
					<td><?php echo $detalle->cantidad; ?></td>
					<td><?php echo $detalle->nombre; ?></td>
					<td><?php echo $detalle->precio; ?></td>
					
					<td><?php echo $detalle->importe; ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>

				<tr>
					<td colspan="3" class="text-right"><strong>Total:</strong></td>
					<td ><?php echo $informes->total; ?></td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>
<div class="row">
<div class="col-xs-12 text-center">
<footer>
<img src="<?php echo base_url();?>assets/img/foo.jpg"width="600" height="75">
</footer>
	</div>
	</div>
