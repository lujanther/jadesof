
	

	<div class="row">
		<div class="col-xs-8">
		<img src="<?php echo base_url();?>assets/img/logo3.jpg">
		</div>

		<div class="col-xs-4">
		<b> <?php echo $venta->tipocomprobante; ?></b> <br>
		<b>Nro:</b> <?php echo $venta->numero_documento; ?><br>
		<b>Fecha</b> <?php echo $venta->fecha; ?><br>
		<b>Nota:</b> <?php echo $venta->notas; ?>
		</div>
	</div>

	<div class="row">
		<div class="col-xs-12">
		<img src="<?php echo base_url();?>assets/img/franja1.jpg">
		</div>
	</div>

<div class="row">
	<div class="col-xs-6">	
		<b>Nombre:</b> <?php echo $venta->nombre; ?> <br>
		<b>NIT/CI:</b> <?php echo $venta->documento; ?><br>
		<b>Ciudad:</b> <?php echo $venta->ciudad; ?><br>
	</div>	
	<div class="col-xs-6">	

	<b>Agencia:</b> <?php echo $venta->agencia; ?> <br>
	<b>Area/Encargado</b> <?php echo $venta->area; ?> <br>
	
</div>	
	
</div>
<br>

<div class="row">
	<div class="col-xs-12" >
	
		<table class="table table-striped">
		
			<thead>
				<tr>
					<th>Cantidad</th>
					<th>Nombre</th>
					<th>Precio</th>
					
					<th>Importe</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($detalles as $detalle ):?>
				<tr>
					<td><?php echo $detalle->cantidad; ?></td>
					<td><?php echo $detalle->nombre; ?></td>
					<td><?php echo $detalle->precio; ?></td>
					
					<td><?php echo $detalle->importe; ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>

				<tr>
					<td colspan="3" class="text-right"><strong>Total:</strong></td>
					<td ><?php echo $venta->total; ?></td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>
<div class="row">
<div class="col-xs-12 text-center">
<footer>
<img src="<?php echo base_url();?>assets/img/foo.jpg"width="600" height="75">
</footer>
	</div>
	</div>
