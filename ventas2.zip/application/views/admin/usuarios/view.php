        <p><strong>Nombres: </strong><?php echo $usuario->nombres; ?></p>
        <p><strong>Apellidos: </strong><?php echo $usuario->apellidos; ?></p>
        <p><strong>Telefono: </strong><?php echo $usuario->telefono; ?></p>
        <p><strong>Correo Electronico: </strong><?php echo $usuario->email; ?></p>
        <p><strong>Username: </strong><?php echo $usuario->username; ?></p>
        <p><strong>Nivel: </strong><?php echo $usuario->rol; ?></p>
